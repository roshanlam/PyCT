from distutils.core import setup

setup(
    name='PyColorText',
    version='0.0.1',
    packages=['PyColorText'],
    url='github.com/roshanlam/PyCT',
    license='',
    author='roshanlam',
    description='A library for colored text'
)
